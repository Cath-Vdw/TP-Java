public class Exo3_1_fiches_inventaire {
    public static void main(String[] args) {
        for (int i = 1; i <= 20; i++) {
            System.out.println("Composant n° " + i + " paré au déploiement.");
        }
    }
}
