public class Exo4_iteration_determinee_controlee {
    public static void main(String[] args) {
        int codeCorrect = 4042;
        int tentativesRestantes = 3;
        int codeSaisi = 4000;
        do {
            if (codeSaisi == codeCorrect) {
                System.out.println("Accès accordé au système.");
                break;
            } else {
                --tentativesRestantes;
                if (tentativesRestantes == 0) {
                    System.out.println("Alerte : Système verrouillé. Intrusion détectée.");
                    break;
                } else {
                    System.out.println("Code incorrect. Il vous reste " + tentativesRestantes + " tentative(s).");
                    codeSaisi += 21;
                }
            }
        } while (codeSaisi != codeCorrect || tentativesRestantes > 0);

    }
}
