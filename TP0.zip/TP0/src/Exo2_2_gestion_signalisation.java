public class Exo2_2_gestion_signalisation {
    static char couleurFeu = 'B';
    public static void main(String[] args) {
       switch (couleurFeu){
           case 'R':
               System.out.println("Arrêt immédiat.");
               break;
           case 'V':
               System.out.println("Le véhicule peut avancer.");
               break;
           case 'O':
               System.out.println("Ralentissez. Le feu va passer au rouge.");
               break;
           default:
               System.out.println("Signal inconnu.");
       }
    }
}
