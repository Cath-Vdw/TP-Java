/**
 * Programme de calcul du tarif d'un billet de cinéma.
 * Le prix dépend de l'âge du client et de la possession
 * d'une carte de fidélité.
 */
public class Exo2_1_calculateur_tarification {

    /**
     * Calcule le prix du billet de cinéma.
     *
     * @param age                   l'âge du client (en années)
     * @param possedeCarteFidelite  true si le client a une carte, false sinon
     * @return                      le montant du billet en euros (0 si gratuit)
     */
    public static int calculerTarif(int age, boolean possedeCarteFidelite) {

        // Cas 1 : enfant de moins de 12 ans -> billet gratuit
        if (age < 12) {
            return 0;
        }
        // Cas 2 : adolescent de 12 à 18 ans inclus
        else if (age <= 18) {
            // Sous-cas : avec ou sans carte de fidélité
            if (possedeCarteFidelite) {
                return 5;   // ado avec carte
            } else {
                return 7;   // ado sans carte
            }
        }
        // Cas 3 : adulte de plus de 18 ans
        else {
            if (possedeCarteFidelite) {
                return 8;   // adulte avec carte
            } else {
                return 11;  // adulte sans carte
            }
        }
    }

    /**
     * Point d'entrée du programme : appelle la méthode de calcul
     * puis affiche le résultat.
     */
    public static void main(String[] args) {

        // On appelle la méthode avec des arguments (âge, carte de fidélité)
        int billet = calculerTarif(12, false);

        // Affichage du résultat
        if (billet == 0) {
            System.out.println("Votre billet est gratuit. Bon film.");
        } else {
            System.out.println("Le montant à régler est de " + billet + " euros.");
        }
    }
}