// nom de la classe principale = nom exacte de la classe Java
public class Exo1_calendar {

    // Méthode principale (point d'entrée du programme)
    public static void main(String[] args) {
        // Code commence ici
        for (int i = 2026; i <= 2500; i++){
            if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
                System.out.println(i);
            }
        }
    }

    // Autres méthodes ou variables si besoin
}