public class Exo3_2_traitement_selectif {
    public static void main(String[] args) {
        for (int i = 1; i <= 20; i++) {
            System.out.print("Composant n° " + i);
            if (i % 5 == 0) {
                System.out.print(" configuré comme Chef de Section. Puissance maximale.\n");
            } else if (i % 2 == 0) {
                System.out.print(" paré au déploiement[Section Bleue]\n");
            } else {
                {
                    System.out.print(" paré au déploiement[Section Rouge]\n");
                }
            }
        }
    }
}
